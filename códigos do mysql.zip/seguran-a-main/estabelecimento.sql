CREATE DATABASE BARES;
USE BARES;

-- COMANDO QUE CRIA UMA TABELA ESTABELECIMENTO. Os "enc" depois do nome dos atributos estão ali para mostrar que aqueles são os atributos encriptados. 
-- O tipo aqui também é VARBINARY porque, ao invés de armazenar texto, armazenará binário.
CREATE TABLE estabelecimento (
	idEstabelecimento INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	
    nome_enc VARBINARY(1024),
    estado_enc VARBINARY(512),
    cidade_enc VARBINARY(512),
    bairro_enc VARBINARY(512),
    rua_enc VARBINARY(1024),
    numero_enc VARBINARY(64),
    reputacao_enc VARBINARY(64),
    situacao_enc VARBINARY(64),
    descricao_enc VARBINARY(4096)
) CHARSET utf8mb4;

DELIMITER // 
-- o delimiter é utilizado para fazer um "bloco de comandos", vamos dizer assim. Um bloco além da separação por ;
-- aqui é onde criamos a primeira procedure. Procedure é como uma função do SQL que poderá ser chamada de novo depois.
-- no caso, essa procedure está criptografando os dados
CREATE PROCEDURE sp_insert_estab(
	IN p_nome VARCHAR(100),
    IN p_estado VARCHAR(50),
    IN p_cidade VARCHAR(50),
    IN p_bairro VARCHAR(50),
    IN p_rua VARCHAR(100), 
    IN p_numero INT,
    IN p_reputacao INT,
    IN p_situacao VARCHAR(10),
    IN p_descricao VARCHAR(600),
    IN p_passphrase VARCHAR(255)
)
BEGIN
	INSERT INTO estabelecimento (
		nome_enc, estado_enc, cidade_enc, bairro_enc,
		rua_enc, numero_enc, reputacao_enc, situacao_enc,
		descricao_enc
	) VALUES (
    -- a função AES_ENCRYPT requer um valor e uma chave. Essa chave é gerada com base na senha criada para a criptografia do banco.
		AES_ENCRYPT(p_nome, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_estado, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_cidade, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_bairro, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_rua, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(CONVERT(p_numero, CHAR), UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(CONVERT(p_reputacao, CHAR), UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_situacao, UNHEX(SHA2(p_passphrase,512))),
		AES_ENCRYPT(p_descricao, UNHEX(SHA2(p_passphrase,512)))
	);
END;
//
DELIMITER ;

DELIMITER //
-- essa próxima procedure permite a leitura dos dados puxando pelo id
CREATE PROCEDURE sp_get_estab_by_id(
	IN p_idEstabelecimento INT,
	IN p_passphrase VARCHAR(255)
)
BEGIN
	SELECT
		idEstabelecimento,
        -- esse "cast" juntamente do AES_DECRYPT é quem vai descriptografar aqueles dados
		CAST(AES_DECRYPT(nome_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(100) CHARACTER SET utf8mb4) AS nome,
		CAST(AES_DECRYPT(estado_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS estado,
		CAST(AES_DECRYPT(cidade_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS cidade,
		CAST(AES_DECRYPT(bairro_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS bairro,
		CAST(AES_DECRYPT(rua_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(100) CHARACTER SET utf8mb4) AS rua,
		CAST(AES_DECRYPT(numero_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(20) CHARACTER SET utf8mb4) AS numero,
		CAST(AES_DECRYPT(reputacao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(10) CHARACTER SET utf8mb4) AS reputacao,
		CAST(AES_DECRYPT(situacao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(10) CHARACTER SET utf8mb4) AS situacao,
		CAST(AES_DECRYPT(descricao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(600) CHARACTER SET utf8mb4) AS descricao
	FROM estabelecimento
	WHERE idEstabelecimento = p_idEstabelecimento;
END;
//
DELIMITER ;

DELIMITER //
-- já essa procedure permite a leitura de todos os dados, sem filtro por id
CREATE PROCEDURE sp_get_all_estab(
	IN p_passphrase VARCHAR(255)
)
BEGIN
	SELECT
		idEstabelecimento,
		CAST(AES_DECRYPT(nome_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(100) CHARACTER SET utf8mb4) AS nome,
		CAST(AES_DECRYPT(estado_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS estado,
		CAST(AES_DECRYPT(cidade_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS cidade,
		CAST(AES_DECRYPT(bairro_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(50) CHARACTER SET utf8mb4) AS bairro,
		CAST(AES_DECRYPT(rua_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(100) CHARACTER SET utf8mb4) AS rua,
		CAST(AES_DECRYPT(numero_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(20) CHARACTER SET utf8mb4) AS numero,
		CAST(AES_DECRYPT(reputacao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(10) CHARACTER SET utf8mb4) AS reputacao,
		CAST(AES_DECRYPT(situacao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(10) CHARACTER SET utf8mb4) AS situacao,
		CAST(AES_DECRYPT(descricao_enc, UNHEX(SHA2(p_passphrase,512))) AS CHAR(600) CHARACTER SET utf8mb4) AS descricao
	FROM estabelecimento;
END;
//
DELIMITER ;

-- essa procedure permite você atualizar um dado por id
DELIMITER //
CREATE PROCEDURE sp_update_estab_by_id(
	IN p_id INT,
	IN p_nome VARCHAR(100),
	IN p_estado VARCHAR(50),
	IN p_cidade VARCHAR(50),
	IN p_bairro VARCHAR(50),
	IN p_rua VARCHAR(100),
	IN p_numero INT,
	IN p_reputacao INT,
	IN p_situacao VARCHAR(10),
	IN p_descricao VARCHAR(600),
	IN p_passphrase VARCHAR(255)
)
BEGIN
	UPDATE estabelecimento
	SET
		nome_enc = AES_ENCRYPT(p_nome, UNHEX(SHA2(p_passphrase,512))),
		estado_enc = AES_ENCRYPT(p_estado, UNHEX(SHA2(p_passphrase,512))),
		cidade_enc = AES_ENCRYPT(p_cidade, UNHEX(SHA2(p_passphrase,512))),
		bairro_enc = AES_ENCRYPT(p_bairro, UNHEX(SHA2(p_passphrase,512))),
		rua_enc = AES_ENCRYPT(p_rua, UNHEX(SHA2(p_passphrase,512))),
		numero_enc = AES_ENCRYPT(CONVERT(p_numero, CHAR), UNHEX(SHA2(p_passphrase,512))),
		reputacao_enc = AES_ENCRYPT(CONVERT(p_reputacao, CHAR), UNHEX(SHA2(p_passphrase,512))),
		situacao_enc = AES_ENCRYPT(p_situacao, UNHEX(SHA2(p_passphrase,512))),
		descricao_enc = AES_ENCRYPT(p_descricao, UNHEX(SHA2(p_passphrase,512)))
	WHERE idEstabelecimento = p_id;
END;
//
DELIMITER ;

-- essa procedure permite você deletar um dado pelo id
DELIMITER //
CREATE PROCEDURE sp_delete_estab_by_id(
	IN p_id INT
)
BEGIN
	DELETE FROM estabelecimento WHERE idEstabelecimento = p_id;
END;
//
DELIMITER ;
