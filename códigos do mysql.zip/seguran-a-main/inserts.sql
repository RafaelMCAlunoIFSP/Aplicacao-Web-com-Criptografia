CALL sp_insert_estab(
	'Bar chove lá fora, aqui dentro só pinga', 
    'Bahia', 
	'Cidade das rosas', 
	'Jardim Florido', 
	'Avenida das Pétalas', 
	12, 
	1, 
	'fechado',
	'O dono deste estabelecimento sempre afirmou que lá dentro os clientes só encontrariam pinga, mas acabaram encontrando altas doses de metanol. Nos copinhos que viravam, a cachaça praticamente não era encontrada, fazendo com que os clientes bebessem metanol puro. E para piorar a situação, o proprietário confessou que comprava bebidas mais baratas para lucrar principalmente nos dias de chuva.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Caixaça econômica', 
	'Minas Gerais', 
	'Cidade das Lanchas', 
	'Água endieirada', 
	'Rua Milionários', 
	23, 
	3, 
	'aberto',
	'Parece que o dono deste bar realmente estava economizando, porque em parte do seu estoque recente, foram encontradas diversas bebidas adulteradas. Até que isso fosse percebido pelos funcionários, diversos clientes consumiram esses produtos e saíram no prejuízo. Assim que foi descoberto, o estabelecimento virou do avesso para manter a qualidade das bebidas, portanto, continua aberto, e agora, com selo de segurança.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Confessionário bar, onde a bebida entra, a verdade sai', 
	'São Paulo', 
	'Cidade dos Gatos', 
	'Pobres e Livres', 
	'Avenida Bigode', 
	34, 
	2, 
	'fechado',
	'A verdade demorou a sair, mas o dono do bar confessou que comprou um lote de bebidas mais baratas, mas que não sabia da adulteração. Durante algumas semanas, o estabelecimento disponibilizou as bebidas adulteradas aos clientes, mas, por sorte, a maioria dos clientes frequentes estava no tribunal, então não houve tanto estrago. Mesmo assim, agora quem irá se encontrar no confessionário é o proprietário do local.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'BomBARdeio', 
	'Rio de Janeiro', 
	'Cidade das Águas', 
	'Rio Azul', 
	'Rua Rio e Mar', 
	45, 
	5, 
	'fechado',
	'Localizado próximo a uma zona mais rica da cidade, o bar sempre teve a preocupação de manter suas bebidas corretas, porque se defender da morte de um rico é mais difícil que de um pobre. O bar estaria aberto até hoje se um dos clientes não tivesse implantado uma bomba no banheiro, explodindo todo o lugar.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Tô no trabalho', 
	'Acre', 
	'Cidade das Palmeiras', 
	'Árvore Verdejante', 
	'Avenida Folha Verde', 
	56, 
	3,
	'aberto',
	'Por um tempo, a não ser que você quisesse trabalhar como anjo da guarda, as autoridades não recomendariam que você frequentasse esse bar. Ele permaneceu fechado durante algumas semanas por causa das bebidas com metanol. Agora, o estabelecimento ficou com má fama, mas ele já possui o selo de fiscalização afirmando que suas bebidas são seguras.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Necrotério bar', 
	'Ceará', 
	'Cidade das Laranjas', 
	'Fruta Madura', 
	'Rua Suco Natural', 
	67, 
	5, 
	'aberto',
	'Apesar do nome mortal, o Necrotério bar sempre foi muito rigoroso na compra de suas bebidas. Comprando apenas de locais com selos de verificação, o estabelecimento passou facilmente pelo teste de presença de metanol nas suas bebidas. Até os mortos gostam de dar uma passadinha lá para beberem com segurança.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Habeas Copos', 
	'Rio Grande do Sul', 
	'Cidade das Avós', 
	'Agulha de Crochê', 
	'Avenida Ponto Alto', 
	78, 
	2,
	'fechado',
	'Habeas copos e habeas metanol também. Um bar conhecido por ser o “after” de muitos estudantes da universidade de história, os jovens não percebiam a diferença no teor alcoólico da bebida, pois já vinham embriagados de outros lugares. Os clientes só perceberam o desastre quando a polícia bateu à porta do estabelecimento e o proprietário precisou pedir pelo seu habeas corpus.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Bartman', 
	'Mato Grosso', 
	'Cidade dos Jegues', 
	'Cavalo Pequeno', 
	'Rua Ferradura Suja', 
	89,
	4,
	'aberto',
	'Um bar de um homem tão rico não poderia ter uma reputação melhor. O proprietário sempre fez questão de garantir a qualidade de suas bebidas. Apesar disso, os clientes acham os preços muito caros para os tipos de bebidas oferecidas e, dizem as más línguas, que os inimigos do dono tentam acabar com a reputação do estabelecimento, porém, ele nunca deixa.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Bar dos otários', 
	'Amazonas', 
	'Cidade dos Ratos', 
	'Bueiro Frio', 
	'Avenida Queijaria Santa', 
	90, 
	4,
	'aberto',
	'Se o próprio dono do bar chama seus clientes de otários, quem somos nós para negar? Sempre se suspeitou que as bebidas deste estabelecimento tinham um “sabor” diferente, mas nunca conseguiram provar nada. Quando fiscalizadas, as bebidas não continham metanol, mas sim altas doses de suco de uva. Ao ser questionado, o proprietário disse que os clientes sempre pediam por bebidas docinhas, então ele decidiu incrementar o suco.',
	'senha-secreta'
);

CALL sp_insert_estab(
	'Oba um bar', 
	'Pernambuco', 
	'Cidade das Fumaças', 
	'Cinza de Fogo', 
	'Rua Fogaréu', 
	1, 
	1,
	'fechado',
	'Todos comemoravam ao ver este bar, mas comemoraram mais ainda quando ele fechou. Após a morte de um casal, mandaram fechar o estabelecimento que, não só vendia a seus clientes bebidas adulteradas, como também colocava metanol nas bebidas e comercializava para outros estabelecimentos. O proprietário do local e seu sócio estão foragidos.',
	'senha-secreta'
);